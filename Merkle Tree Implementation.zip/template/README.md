Project Group #96

Group Members: 
- William O     o0000006
- Anna Ton Nu   tonnu016
- Thuy-Yen Tran tran0982

CSELab computer: csel-khl250-36.cselabs.umn.edu

Workload Division: 
    William was able to work on implementing the partitioning file date section of the project. As well as the minor TODOs in the merkle.c file. Anna worked on the initial creation block files in utils and the hash files in child_process.c as well the section when the current process is a leaf process. Thuy-Yen finished out the child_process.c section where she handled the condition that the current process was not a leaf process. Throughout the project, however, we always turned to each other whenever we were running into problems in our sections code or needed clarifications on the logic of the intended goal.

Changes to files:
	No changes were made outside of the required coding were made 

Additional Assumptions:
	No additional assumptions were made

Implementation:

Original Design

For(int i = 0; i < length of argument; i++){
	if(current process is leaf process){
		Hash block file
		Write the created hash to its hash file
		Break out of the leaf process
	}
	Else if (current process is not a leaf process){
		Fork current process to create 2 child processes
		Run ./child_process using exec() with child ID parameter
		Have parent process wait for child process to complete
		Read hash values from child process
		Concatenate and write the two hash values to parent processâ hash
	}
}

New Design

If (current process is leaf)
	Hash corresponding block file using hash_data_block
	Write hash into a created hash file
Else if( current process is not a leaf)
	Fork a left child process and fork a right child process
	Run ./child_process using execl with its corresponding childID 
	have parents wait for child processes to finish
	
	Once child processes are complete, retrieve hash value from both left and right child
	Use compute_dual_hash to concatenate left and right hash
	Write full hash into a file.

Return 0

Our new design is different from our original design because we thought that we would need a for loop to create the child processes like a process fan. After further inspection we realized the recursive nature of using execl and we realized that we don’t need a for loop at all.



AI: N/A