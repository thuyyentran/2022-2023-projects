#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include "hash.h"

#define PATH_MAX 1024

int main(int argc, char *argv[])
{
    if (argc != 5)
    {
        printf("Usage: ./child_process <blocks_folder> <hashes_folder> <N> <child_id>\n");
        return 1;
    }
    char *blocks_folder = argv[1];
    char *hashes_folder = argv[2];
    int n = atoi(argv[3]);
    int child_id = atoi(argv[4]);
    char blockname[PATH_MAX];
    char hashname[PATH_MAX];

    // TODO: If the current process is a leaf process, read in the associated block file
    // and compute the hash of the block.

    if (child_id >= n - 1)
    {
        int blockID = child_id - n + 1; // determine which block file corresponds with child ID
        snprintf(blockname, PATH_MAX, "%s/%d.txt", blocks_folder, blockID);
        snprintf(hashname, PATH_MAX, "%s/%d.out", hashes_folder, child_id);

        FILE *hash_file = fopen(hashname, "w");
        if (hash_file == NULL)
        {
            perror("Error opening hash file");
            exit(-1);
        }

        char computed_hash[SHA256_BLOCK_SIZE * 2 + 1];
        hash_data_block(computed_hash, blockname); // compute hash based on corresponding block file

        fwrite(computed_hash, 1, SHA256_BLOCK_SIZE * 2 + 1, hash_file); // write to hash file in folder

        fclose(hash_file);
    }

    // TODO: If the current process is not a leaf process, spawn two child processes using
    // exec() and ./child_process.
    else
    {
        int leftID = 2 * child_id + 1;
        int rightID = 2 * child_id + 2;

        pid_t lpid = fork(); // left child
        if (lpid == 0)
        {
            char strLID[8] = "";
            sprintf(strLID, "%d", leftID);
            execl("./child_process", "./child_process", blocks_folder, hashes_folder, argv[3], strLID, NULL);
        }

        pid_t rpid = fork(); // right child
        if (rpid == 0)
        {
            char strRID[8] = "";
            sprintf(strRID, "%d", rightID);
            execl("./child_process", "./child_process", blocks_folder, hashes_folder, argv[3], strRID, NULL);
        }

        // TODO: Wait for the two child processes to finish

        int status;
        waitpid(lpid, &status, 0);
        waitpid(rpid, &status, 0);
        // TODO: Retrieve the two hashes from the two child processes from output/hashes/
        // and compute and output the hash of the concatenation of the two hashes.
        char l_hash_name[PATH_MAX];
        char r_hash_name[PATH_MAX];
        snprintf(l_hash_name, PATH_MAX, "%s/%d.out", hashes_folder, leftID);
        snprintf(r_hash_name, PATH_MAX, "%s/%d.out", hashes_folder, rightID);

        char l_hash[SHA256_BLOCK_SIZE * 2 + 1];
        char r_hash[SHA256_BLOCK_SIZE * 2 + 1];

        FILE *l_hash_file = fopen(l_hash_name, "r"); // retrive left hash
        if (l_hash_file == NULL)
        {
            perror("Error opening left hash file");
            exit(-1);
        }
        fread(l_hash, 1, SHA256_BLOCK_SIZE * 2 + 1, l_hash_file);
        fclose(l_hash_file);

        FILE *r_hash_file = fopen(r_hash_name, "r"); // retrive right hash
        if (r_hash_file == NULL)
        {
            perror("Error opening right hash file");
            exit(-1);
        }
        fread(r_hash, 1, SHA256_BLOCK_SIZE * 2 + 1, r_hash_file);
        fclose(r_hash_file);

        char full_hash[SHA256_BLOCK_SIZE * 2 + 1];
        compute_dual_hash(full_hash, l_hash, r_hash); // concatenate left and right hash

        snprintf(hashname, PATH_MAX, "%s/%d.out", hashes_folder, child_id);

        FILE *full_hash_file = fopen(hashname, "w");
        if (full_hash_file == NULL)
        {
            perror("Error opening full hash");
            exit(-1);
        }
        fwrite(full_hash, 1, SHA256_BLOCK_SIZE * 2 + 1, full_hash_file); // write full hash into full hash file
        fclose(full_hash_file);
    }

    return 0;
}