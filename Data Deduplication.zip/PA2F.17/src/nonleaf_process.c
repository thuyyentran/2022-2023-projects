#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include "../include/hash.h"

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: ./nonleaf_process <directory_path> <pipe_write_end> \n");
        return 1;
    }
    
    //TODO(overview): fork the child processes(non-leaf process or leaf process) each associated with items under <directory_path>

    //TODO(step1): get <file_path> <pipe_write_end> from argv[]
    char *directory_path = argv[1];
    int pipe_write_end = atoi(argv[2]);

    //TODO(step2): malloc buffer for gathering all data transferred from child process as in root_process.c
    // char *buffer = malloc(15*(PATH_MAX + SHA256_BLOCK_SIZE * 2 + 1 + 3));
    char *buffer = malloc(4098);
    memset(buffer, 0, sizeof(buffer));
    //TODO(step3): open directory
    DIR *directory = opendir(directory_path);

    //TODO(step4): traverse directory and fork child process
    // Hints: Maintain an array to keep track of each read end pipe of child process
    struct dirent *entry;
    int read_end[10];
    int count = 0;
    while(((entry = readdir(directory))!= NULL)){
        char path[1024];
        sprintf(path, "%s/%s",directory_path,entry->d_name);
        
         if(strcmp(entry->d_name,".")!= 0 && strcmp(entry->d_name, "..")!= 0){
            int pipe_fd[2];
            pipe(pipe_fd);
            pid_t pid = fork();
            char write_str[50];
            sprintf(write_str, "%d", pipe_fd[1]);
            if(pid == 0){
                close(pipe_fd[0]);
                if(entry->d_type == DT_DIR){ 
                    execl("./nonleaf_process", "./nonleaf_process",path,write_str, NULL);
                }
                else if(entry->d_type == DT_REG){
                     execl("./leaf_process", "./leaf_process",path,write_str, NULL);
                }
            }
            else{
                close(pipe_fd[1]);
                wait(NULL);
                read_end[count] = pipe_fd[0];
                count++;
            }
         }
    }
    
    closedir(directory);

    //TODO(step5): read from pipe constructed for child process and write to pipe constructed for parent process


    char *string_pipe = malloc(PATH_MAX + SHA256_BLOCK_SIZE * 2 + 3);
    
     for(int i = 0; i<count; i++){
        memset(string_pipe, 0, sizeof(string_pipe));
        read(read_end[i],string_pipe,PATH_MAX + SHA256_BLOCK_SIZE * 2 + 3);
        strncat(buffer,string_pipe, PATH_MAX + SHA256_BLOCK_SIZE * 2 + 3);
        close(read_end[i]);
        
    }
    
    // write(pipe_write_end, buffer,15*(PATH_MAX + SHA256_BLOCK_SIZE * 2 + 1 + 3));
    write(pipe_write_end, buffer,4098);
    free(buffer);
    free(string_pipe);
    

}
