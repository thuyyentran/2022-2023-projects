#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "../include/utils.h"
#include "../include/hash.h"

#define WRITE (O_WRONLY | O_CREAT | O_TRUNC)
#define PERM (S_IRUSR | S_IWUSR)
char *output_file_folder = "output/final_submission/";

void redirection(char **dup_list, int size, char* root_dir){
    // TODO(overview): redirect standard output to an output file in output_file_folder("output/final_submission/")
    // TODO(step1): determine the filename based on root_dir. e.g. if root_dir is "./root_directories/root1", the output file's name should be "root1.txt"
    char out_filename[PATH_MAX];
    char *root_directory = extract_root_directory(root_dir);
    //char *root_directory = strstr(root_dir, "/roots/");
    snprintf(out_filename,PATH_MAX, "%s%s.txt", output_file_folder, root_directory);

    //TODO(step2): redirect standard output to output file (output/final_submission/root*.txt)

    int output = open(out_filename, WRITE, PERM);

     if(dup2(output, STDOUT_FILENO)==-1){
        perror("Failed to redirect output\n");
     }

    //TODO(step3): read the content each symbolic link in dup_list, write the path as well as the content of symbolic link to output file(as shown in expected)
    
     for (int i = 0; i < size; i++){
        printf("[<path of symbolic link> --> <path of retained file>] : ");
        char path[PATH_MAX];
        memset(path, 0, sizeof(path));
        int size=readlink(dup_list[i],path, sizeof(path)-1);
        path[size] = '\0';

        
        printf("[%s --> %s]\n", dup_list[i],path);
         
     }
     fflush(stdout);

    close(output);
    free(root_directory);
}

void create_symlinks(char **dup_list, char **retain_list, int size) {
    //TODO(): create symbolic link at the location of deleted duplicate file
    //TODO(): dup_list[i] will be the symbolic link for retain_list[i]
    for(int i = 0; i < size; i++){
        if(dup_list[i] != NULL && retain_list[i] != NULL){
            symlink(retain_list[i], dup_list[i]);
            if(symlink(retain_list[i], dup_list[i]) != 0){
                perror("Error in creating symbolic link\n");
            }

        }
    }


}

void delete_duplicate_files(char **dup_list, int size) {
    //TODO(): delete duplicate files, each element in dup_list is the path of the duplicate file
    //   if (size <= 0 || dup_list == NULL){
    //     printf("No duplicate files to delete \n");
    // }
    for(int i = 0; i < size; i++){
        if (dup_list[i] != NULL) {
           
            if (remove(dup_list[i]) != 0) {
                perror("Error deleting duplicate file\n");
            }
        }
    }


}

// ./root_directories <directory>
int main(int argc, char* argv[]) {
    if (argc != 2) {
        // dir is the root_directories directory to start with
        // e.g. ./root_directories/root1
        printf("Usage: ./root <dir> \n");
        return 1;
    }

    //TODO(overview): fork the first non_leaf process associated with root directory("./root_directories/root*")

    char* root_directory = argv[1];
    char all_filepath_hashvalue[4098]; //buffer for gathering all data transferred from child process
    memset(all_filepath_hashvalue, 0, sizeof(all_filepath_hashvalue));// clean the buffer

    //TODO(step1): construct pipe
    int pipe_fd[2];
    pipe(pipe_fd);

    //TODO(step2): fork() child process & read data from pipe to all_filepath_hashvalue
    pid_t pid = fork();
    if(pid == 0){
        close(pipe_fd[0]);
        char write_str[50];
        sprintf(write_str, "%d", pipe_fd[1]);
        execl("./nonleaf_process", "./nonleaf_process",root_directory,write_str, NULL);
    }
    else{
        close(pipe_fd[1]);
        wait(NULL);
        read(pipe_fd[0], all_filepath_hashvalue, 4098);
    }
    

    //TODO(step3): malloc dup_list and retain list & use parse_hash() in utils.c to parse all_filepath_hashvalue
    // dup_list: list of paths of duplicate files. We need to delete the files and create symbolic links at the location
    // retain_list: list of paths of unique files. We will create symbolic links for those files
    char** dup_list = malloc(10 * sizeof(char*));
    char** retain_list = malloc(10 * sizeof(char*));


    if (!dup_list || !retain_list) {
        fprintf(stderr, "Memory allocation failed!\n");
        return 1;
    }
    
    for (int i = 0; i < 10; i++) {
        dup_list[i] = NULL;
        retain_list[i] = NULL;
    }


    int size = parse_hash(all_filepath_hashvalue, dup_list, retain_list);


    //TODO(step4): implement the functions
    delete_duplicate_files(dup_list,size);
    create_symlinks(dup_list, retain_list, size);
    redirection(dup_list, size, argv[1]);
    

    //TODO(step5): free any arrays that are allocated using malloc!!
//    for (int i = 0; i < 10; i++) {
//         if (dup_list[i]) free(dup_list[i]);
//         if (retain_list[i]) free(retain_list[i]);
//     }
    free(dup_list);
    free(retain_list);
    dup_list = NULL;
    retain_list = NULL;
}
