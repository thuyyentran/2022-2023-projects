README.md:

Project Group #96

Group Members: 
- William O     o0000006
- Anna Ton Nu   tonnu016
- Thuy-Yen Tran tran0982

CSELab computer: 
csel-khl250-36.cselabs.umn.edu

Workload Division:

William and Thuy-Yen both worked on root_processes.c. William implemented redirection and created symlink while Thuy-Yen worked on delete duplicate files and the main function. Anna Worked on non-leaf process and pipe communication between leaf, non leaf and root. We all helped each other out when someone needed help.


Changes to Makefile and files:
For the Makefile, we took a new file that was given to us by the instructors on piazza because the initial Makefile given was preventing us from being able to compile the code properly. We also used the updated utils.c file given to us. We changed extract_root_directory in utils to use /roots/ instead of /root_directories/ for gradescope tests.


Assumptions:
None


Design:

Root_process.
-Create pipe to share between parent and child
-Fork to create root process
-Child process execl to run nonleaf process. Sends in write end of pipe and root directory
-Parent waits then reads in all information gathered from the entire tree from read end
-Use parse hash to split up files and hash into dup_list and retain_list
-Delete duplicate files
-Create symlinks for those deleted files
-Redirect and print out output in a file.

Non Leaf process:
-Open directory and start to traverse through each entry using a loop
-For each iteration, create a pipe and then fork.
-If entry is a directory then child should execl to nonleaf process
-If entry is a file then child should execl to leaf process
-Either execl should take in path and write end of pipe as arguments so child can communicate with parent
-parent waits and stores read ends of all pipes shared with its children in an array while also keeping a count of how many children processes are created.
- read from all the read ends and concatenate all of the contents 
- write to pipe write end that was given as an argument

Leaf process:
-hash file path
- create a string that includes file path and hash split up with “|”
- write string to write end of pipe given as an argument


Our Design did not change that much but we gained a stronger understanding of how the pipes were used to communicate between processes.


AI: None

