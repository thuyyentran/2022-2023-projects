// Template to complete the loadfunc program which locates a function
// in the text section of an ELF file. Sections that start with a
// CAPITAL in their comments require additions and modifications to
// complete the program (unless marked as PROVIDED).

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <elf.h>

// macro to add a byte offset to a pointer
#define PTR_PLUS_BYTES(ptr,off) ((void *) (((size_t) (ptr)) + ((size_t) (off))))

// address at which to map the ELF file
#define MAP_ADDRESS  ((void *) 0x0000600000000000)

int main(int argc, char **argv){
  // PROVIDED: command line checks for proper # args
  if(argc < 2){                 
    printf("usage: %s <file>\n",argv[0]);
    return 0;
  }

  // PROVIDED: required command line arguments
  char *objfile_name = argv[1]; // name of file to operate  on
                        
  // PROVIDED: open file to get file descriptor, determine file size
  int fd = open(objfile_name, O_RDONLY);  // open file to get file descriptor
  struct stat stat_buf;         
  fstat(fd, &stat_buf);  // call fstat() to fill in fields like size of file
  int size =  stat_buf.st_size;   

  // CREATE memory map via mmap() call, ensure that pages are readable
  // AND executable. Map to virtual address MAP_ADDRESS, first arg to mmap().
  char *file_bytes = mmap(MAP_ADDRESS, size, PROT_READ | PROT_EXEC, MAP_PRIVATE, fd, 0); // pointer to file contents

  // CHECK for failure in memory map, print message and return 1 if
  // failed; otherwise, print pointer value of memory map
  if(file_bytes == 0){ 
    printf("ERROR: failed to mmap() file %s\n",objfile_name);
    return 1;
  }
  printf("file_bytes at: %p\n",file_bytes);

  // CREATE A POINTER to the intial bytes of the file which are an ELF64_Ehdr struct
  Elf64_Ehdr *ehdr = PTR_PLUS_BYTES(file_bytes, 0); 

  // CHECK e_ident field's bytes 0 to for for the sequence {0x7f,'E','L','F'}.
  // Exit the program with code 1 if the bytes do not match
  int magic_match =
    ehdr->e_ident[0] == 0x7f &&
    ehdr->e_ident[1] == 'E'  &&
    ehdr->e_ident[2] == 'L'  &&
    ehdr->e_ident[3] == 'F';

  if(!magic_match){
    printf("ERROR: Magic bytes wrong, this is not an ELF file\n");
    return 1;
  }

  // PROVIDED: check for a 64-bit file
  if(ehdr->e_ident[EI_CLASS] != ELFCLASS64){
    printf("ERROR: Not a 64-bit file ELF file\n");
    return 1;
  }

  // PROVIDED: check for x86-64 architecture
  if(ehdr->e_machine != EM_X86_64){
    printf("ERROR: Not an x86-64 file\n");
    return 1;
  }
  // could check hear for ehdr->e_ident[EI_OSABI] for ELFOSABI_LINUX


  // SET UP a pointer to the array of section headers.  Determine the
  // offset of the Section Header Array (e_shoff) and the number of
  // sections (e_shnum). These fields are from the ELF File
  // Header. The print accroding to the format below
  Elf64_Shdr *shdr = (Elf64_Shdr *)(PTR_PLUS_BYTES(file_bytes, ehdr->e_shoff));
  printf("Section Headers Found:\n");
  printf("- %lu bytes from start of file\n", ehdr->e_shoff);
  printf("- %hu sections total\n", ehdr->e_shnum);
  printf("- %p section header virtual address\n", shdr);

  // SET UP a pointer to the Section Header String Table
  // .shstrtab. Find the its section index in the ELF header with the
  // fiel (e_shstrndx).  The index into the array of section headers
  // to find the position in the file and set up a pointer to it. See
  // the spec diagram for a visual representation.
  uint16_t shstrndx = ehdr->e_shstrndx; // index of the section header string table
  char *shstrtab = PTR_PLUS_BYTES(file_bytes, shdr[shstrndx].sh_offset); // pointer to the section header string table
  printf("Section Header Names in Section %d\n", shstrndx);
  printf("- %lu bytes from start of file\n", shdr[shstrndx].sh_offset);
  printf("- %lu total bytes\n",  shdr[shstrndx].sh_size);
  printf("- %p .shstrtab virtual address\n", shstrtab);

  // SEARCH the Section Header Array for sections with names .symtab
  // (symbol table) and .strtab (string table).  Note their positions
  // in the file (sh_offset field).  Also note the size in bytes
  // (sh_size) and and the size of each entry (sh_entsize) for .symtab
  // so its number of entries can be computed.
  Elf64_Shdr *symtab_sh = NULL; 
  Elf64_Shdr *strtab_sh = NULL;   

  printf("\n");
  printf("Scanning Section Headers for Relevant Sections\n");
  for(int i=0; i<ehdr->e_shnum; i++){   
    char *secname = PTR_PLUS_BYTES(shstrtab, shdr[i].sh_name);
    printf("[%2d]: %s\n",i,secname);

    if (strcmp(secname, ".symtab") == 0) { // CHECK for .symtab
      symtab_sh = &shdr[i];
    } 
    else if (strcmp(secname, ".strtab") == 0) { // CHECK for .strtab
        strtab_sh = &shdr[i];
    }
  }

  printf("\n");

  // CHECK that the symbol table was found; if not, error out. SET UP
  // a pointer to the .symtab section and print information as shown.
  if(symtab_sh == NULL){
    printf("ERROR: Couldn't find symbol table\n");
    return 1;
  }
  uint64_t symtab_num = symtab_sh->sh_size / symtab_sh->sh_entsize;
  Elf64_Sym *symtab = (Elf64_Sym *)((uintptr_t)file_bytes + symtab_sh->sh_offset);
  printf(".symtab located\n");
  printf("- %lu bytes from start of file\n", symtab_sh->sh_offset);
  printf("- %lu bytes total size\n", symtab_sh->sh_size);
  printf("- %lu bytes per entry\n", symtab_sh->sh_entsize);
  printf("- %lu number of entries\n", symtab_num);
  printf("- %p .symtab virtual addres\n", symtab);


  // CHECK that .strtab (string table) section is found. Error out if
  // not. SET UP a pointer to it and print information as shown.
  if(strtab_sh == NULL){
    printf("ERROR: Couldn't find .strtab section\n");
    return 1;
  }
  char *strtab = PTR_PLUS_BYTES(file_bytes, strtab_sh->sh_offset);
  printf(".strtab located\n");
  printf("- %lu bytes from start of file\n", strtab_sh->sh_offset);
  printf("- %lu total bytes in section\n",  strtab_sh->sh_size);
  printf("- %p .strtab virtual addres\n", strtab);

  printf("\n");
  printf("SYMBOL TABLE CONTENTS\n");
  printf("[%3s]  %8s %4s %s\n","idx","TYPE","SIZE","NAME");

  // ITERATE through the symbol table (.symtab section), an array of
  // Elf64_Sym structs. Print the contents of each entry according to
  // the following format:
  // 
  // SYMBOL TABLE CONTENTS
  // [idx]      TYPE SIZE NAME
  // [  0]:   NOTYPE    0 <NONE>
  // [  1]:     FILE    0 x.c
  // [  2]:  SECTION    0 <NONE>
  // [  3]:  SECTION    0 <NONE>
  // [  4]:  SECTION    0 <NONE>
  // [  5]:  SECTION    0 <NONE>
  // [  6]:  SECTION    0 <NONE>
  // [  7]:  SECTION    0 <NONE>
  // [  8]:   OBJECT  512 arr
  // [  9]:     FUNC   17 func

  Elf64_Sym *symtable_entry = (Elf64_Sym *)((char *)file_bytes + symtab_sh->sh_offset);
  for(uint64_t i=0; i<symtab_num; i++){
    // LOCATE the name of the symbol and print it or <NONE> if no name
    // has length 0
    char *name = strtab + symtable_entry[i].st_name;
    if(symtable_entry[i].st_name == 0) {
        name = "<NONE>";
    }
    
    // USE MACRO ELF64_ST_TYPE() on symtable_entry[i].st_info to
    // determine and print its type.
    char *type_str = "";
    switch(ELF64_ST_TYPE(symtable_entry[i].st_info)) {
        case STT_NOTYPE:
            type_str = "NOTYPE";
            break;
        case STT_OBJECT:
            type_str = "OBJECT";
            break;
        case STT_FUNC:
            type_str = "FUNC";
            break;
        case STT_SECTION:
            type_str = "SECTION";
            break;
        default:
            type_str = "FILE";
    }
    
    uint64_t size = symtable_entry[i].st_size; // find the size of the symbol
    printf("[%3lu]: %8s %4lu %s\n", i, type_str, size, name); // print the symbol table entry
  
    // LOCATE the name of the symbol and print it or <NONE> if no name
    // has length 0
    // 
    // USE MACRO ELF64_ST_TYPE() on symtable_entry[i].st_info to
    // determine and print its type. This will involve a sequence of
    // if/else statements or a switch()
    //
    // FIND THE SIZE of the symbol which is in a field of the symbol
    // table entry. Consult the documentation for the struct, perhaps
    // by typing `man elf` in a terminal and searching for the
    // Elf64_Sym struct documentation.
  }

  printf("\n");
  munmap(file_bytes, size); // Unmap 
  close(fd); // Close the open file
  return 0;
}
