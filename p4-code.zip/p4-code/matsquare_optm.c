// optimized versions of matrix diagonal summing
#include "matvec.h"

int matsquare_VER1(matrix_t *mat, matrix_t *matsq) {
  int rows = mat->rows; //local variables
  int cols = mat->cols;

  matrix_t mat1 = *mat;//macro functions
  matrix_t matsq1 = *matsq;

  int i,j,k; //initialize i,j,k
  for(i = 0; i < rows; i++){
    for(j = 0; j < cols; j++){
      MSET(matsq1,i,j,0); // initialize to 0s
    }
  }

  for(i = 0; i < rows; i++){
    for(j = 0; j < cols; j++){
      int mik = MGET(mat1, i, j); //pre-calculate mik since it will be the same with every loop
      for(k = 0; k < rows - 3; k += 3){ // loop unrolling
        int new = MGET(matsq1, i, k + 0) + mik*MGET(mat1, j, k + 0); // int new = cur + mik*mkj; reduced variable assigments
        MSET(matsq1, i, k + 0, new); // fixed target index
        int new1 = MGET(matsq1, i, k + 1) + mik*MGET(mat1, j, k + 1); // int new1 = cur1 + mik1*mkj1; reduced variable assigments
        MSET(matsq1, i, k + 1, new1); // fixed target index
        int new2 = MGET(matsq1, i, k + 2) + mik*MGET(mat1, j, k +2 );  // int new2 = cur2 + mik2*mkj2; reduced variable assigments
        MSET(matsq1, i, k + 2, new2); // fixed target index
      }

      for(; k < rows; k++){ //accessing remaining elements
        int new = MGET(matsq1, i, k + 0) + mik*MGET(mat1, j, k + 0); // int new = cur + mik*mkj;
        MSET(matsq1, i, k + 0, new); // fixed target index
      }
    }
  }
  return 0; // return success
}

int matsquare_OPTM(matrix_t *mat, matrix_t *matsq){
  if(mat->rows != mat->cols   ||      // must be a square matrix to square it
     mat->rows != matsq->rows ||
     mat->cols != matsq->cols)
  {
    printf("matsquare_OPTM: dimension mismatch\n");
    return 1;
  }

  // Call to some version of optimized code
  return matsquare_VER1(mat, matsq);
}
/////////////////////////////////////////////////////////////////////////////////
// ADDITIONAL INFORMATION
//
// (A) VERSION: If you implemented several versions, indicate which
// version you timed
// 
// ####################### VER1 is timed #########################
// 
// ##################################################################
// 
//
// (B) TIMING ON loginNN.cselabs.umn.edu:
// Paste a copy of the results of running matsquare_benchmark on the
// above machines in the space below which shows how your performance
// optimizations improved on the baseline codes.

// tran0982@csel-remote-lnx-01:/home/tran0982/Desktop/p4-code $ ./matsquare_benchmark
// ==== Matrix Square Benchmark Version 2 ====
//   SIZE       BASE       OPTM  SPDUP   LOG2  SCALE POINTS 
//    256 4.0727e-01 6.6932e-02   6.08   2.61   0.94   2.44 
//    273 4.2341e-01 6.5028e-02   6.51   2.70   1.00   2.70 
//    512 4.2003e+00 8.1187e-01   5.17   2.37   1.88   4.45 
//    801 1.4344e+01 2.8604e+00   5.01   2.33   2.93   6.83 
//   1024 4.6479e+01 9.3657e+00   4.96   2.31   3.75   8.67 
// RAW POINTS: 25.09
// TOTAL POINTS: 25 / 30
// 
// ####################### tran0982@csel-remote-lnx-01:/home/tran0982/Desktop/p4-code $ ./matsquare_benchmark
// tran0982@csel-remote-lnx-01:/home/tran0982/Desktop/p4-code $ ./matsquare_benchmark
// ==== Matrix Square Benchmark Version 2 ====
//   SIZE       BASE       OPTM  SPDUP   LOG2  SCALE POINTS 
//    256 3.9997e-01 5.5111e-02   7.26   2.86   0.94   2.68 
//    273 4.7057e-01 4.7815e-02   9.84   3.30   1.00   3.30 
//    512 3.8742e+00 7.9677e-01   4.86   2.28   1.88   4.28 
//    801 1.4257e+01 2.4171e+00   5.90   2.56   2.93   7.51 
//   1024 4.6781e+01 6.1366e+00   7.62   2.93   3.75  10.99 
// RAW POINTS: 28.76
// TOTAL POINTS: 29 / 30

// tran0982@csel-remote-lnx-01:/home/tran0982/Desktop/p4-code $ ./matsquare_benchmark
// ==== Matrix Square Benchmark Version 2 ====
//   SIZE       BASE       OPTM  SPDUP   LOG2  SCALE POINTS 
//    256 4.0017e-01 5.6667e-02   7.06   2.82   0.94   2.64 
//    273 4.0552e-01 4.6039e-02   8.81   3.14   1.00   3.14 
//    512 3.8876e+00 7.6002e-01   5.12   2.35   1.88   4.42 
//    801 1.4298e+01 1.6691e+00   8.57   3.10   2.93   9.09 
//   1024 4.5701e+01 6.3237e+00   7.23   2.85   3.75  10.70 
// RAW POINTS: 29.99
// TOTAL POINTS: 30 / 30

// tran0982@csel-remote-lnx-01:/home/tran0982/Desktop/p4-code $ ./matsquare_benchmark
// ==== Matrix Square Benchmark Version 2 ====
//   SIZE       BASE       OPTM  SPDUP   LOG2  SCALE POINTS 
//    256 4.1498e-01 6.0604e-02   6.85   2.78   0.94   2.60 
//    273 4.0847e-01 4.6372e-02   8.81   3.14   1.00   3.14 
//    512 3.8544e+00 7.2386e-01   5.32   2.41   1.88   4.52 
//    801 1.4650e+01 1.6031e+00   9.14   3.19   2.93   9.37 
//   1024 4.4724e+01 6.4021e+00   6.99   2.80   3.75  10.52 
// RAW POINTS: 30.15
// TOTAL POINTS: 30 / 30
// tran0982@csel-remote-lnx-01:/home/tran0982/Desktop/p4-code $ ./matsquare_benchmark
// ==== Matrix Square Benchmark Version 2 ====
//   SIZE       BASE       OPTM  SPDUP   LOG2  SCALE POINTS 
//    256 3.9834e-01 4.8821e-02   8.16   3.03   0.94   2.84 
//    273 4.1882e-01 6.0135e-02   6.96   2.80   1.00   2.80 
//    512 3.8291e+00 3.8258e-01  10.01   3.32   1.88   6.23 
//    801 1.4080e+01 1.5151e+00   9.29   3.22   2.93   9.44 
//   1024 4.9838e+01 3.2503e+00  15.33   3.94   3.75  14.77 
// RAW POINTS: 36.08
// TOTAL POINTS: 30 / 30
// 
// ##################################################################
// 
// (C) OPTIMIZATIONS:
// Describe in some detail the optimizations you used to speed the code
// up.  THE CODE SHOULD CONTAIN SOME COMMENTS already to describe these
// but in the section below, describe in English the techniques you used
// to make the code run faster.  Format your descriptions into discrete
// chunks such as.
// 
// Optimization 1: Macro Functions... This should make run faster because
// yakkety yakeety yak.
// 
// Optimization 2: Loop unrolling... This should make run faster because
// yakkety yakeety yak.
// ...
// Optimization N: Reduced variable assigments and local variables and precalulating variables before for-loops... This should make run faster because
// yakkety yakeety yak.
// 
// Full credit solutions will describe 2-3 optimizations and describe
// WHY these improved performance in at least a couple sentences.
// 
// Optimization 1: Macro Functions: Macro functions are a way to reduce the overhead of function calls, 
// as they are replaced by their definitions at compile-time. In this case, the MSET and MGET macros are 
// used to set and get values in the matrices. By using macros functions, I reduced the overhead of 
// function calls and improved performance, making the code run faster. This is because macro functions 
// are essentially inline code that gets substituted into the program wherever they are used. 
// In the case of the MSET and MGET macros used in the matsquare_VER1 function, this meant that instead of calling 
// a function to set or get a value in the matrix, the code simply performs the operation directly.
// 
// Optimization 2: Loop unrolling: Loop unrolling is a technique that reduces the overhead of loop 
// control statements by manually repeating loop iterations. When a loop is unrolled, 
// multiple iterations of the loop are performed within a single loop construct, effectively reducing the
// number of times the loop condition is evaluated and the loop counter is incremented. In the case of 
// the matsquare_VER1 function, the innermost loop has been unrolled by a factor of 3, which can 
// reduce the overhead associated with loop control structures and improve performance, making the code
// run faster.
//
// Optimization 3: Reduced variable assigments and local variables and precalulating variables before for-loops:
// Reducing variable assignments and pre-calculating variables before for-loops can help speed up code by reducing
// the amount of work that needs to be done within the for-loop. I reduced the number of variable assignments 
// by precalculating the value of mik before the innermost loop, instead of recalculating it every iteration. 
// Additionally, I initialized the local variables for rows and cols to avoid accessing the struct every time 
// we need these values. I also reduced the number of variable assignments by reusing variables and avoiding 
// redundant computations. Additionally, by using fixed target indices in the innermost loop, the 
// amount of work required to compute the indices of each element in the matrix is reduced. These optimizations 
// helped to reduce the overhead of variable assignments and improved performance, making the code run faster.
// #########################
// 
// ##################################################################
