#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "clock.h"


int set_tod_from_ports(tod_t *tod){

    // the two cases below checks for when TIME_OF_DAY_PORT is negative or larger than 16 times the number of seconds in a day
    if(TIME_OF_DAY_PORT < 0){
        return 1;
    }
    if(TIME_OF_DAY_PORT > (16*86400)){ //1382400, checks
        return 1;
    }

    //using mask and shifts to determine rounding
    tod->day_secs = TIME_OF_DAY_PORT >> 4;
    int mask = (1 << 4) - 1;
    if((mask & TIME_OF_DAY_PORT) > 8){
        tod->day_secs += 1;
    }
    tod->time_secs = tod->day_secs % 60;
    tod->time_mins = (tod->day_secs / 60) % 60;  

    int hours = tod->day_secs/3600;
    if (hours < 1){ //case for when midnight
        tod->ampm = 1;
        tod->time_hours = 12;
    }
    else if(hours < 12){ //case for before noon after 1 am
        tod->ampm = 1;
        tod->time_hours = hours;
    }
    else if(hours == 12){ //case for when it is noon
        tod->ampm = 2;
        tod->time_hours = 12;
    }
    else{ //case for the afternoon
        tod->ampm = 2;
        tod->time_hours = hours - 12;
    }
    return 0;
}
// Reads the time of day from the TIME_OF_DAY_PORT global variable. If
// the port's value is invalid (negative or larger than 16 times the
// number of seconds in a day) does nothing to tod and returns 1 to
// indicate an error. Otherwise, this function uses the port value to
// calculate the number of seconds from start of day (port value is
// 16*number of seconds from midnight). Rounds seconds up if there at
// least 8/16 have passed. Uses shifts and masks for this calculation
// to be efficient. Then uses division on the seconds since the
// begining of the day to calculate the time of day broken into hours,
// minutes, seconds, and sets the AM/PM designation with 1 for AM and
// 2 for PM. By the end, all fields of the `tod` struct are filled in
// and 0 is returned for success.
 // 
// CONSTRAINT: Uses only integer operations. No floating point
// operations are used as the target machine does not have a FPU.
// 
// CONSTRAINT: Limit the complexity of code as much as possible. Do
// not use deeply nested conditional structures. Seek to make the code
// as short, and simple as possible. Code longer than 40 lines may be
// penalized for complexity.

int set_display_from_tod(tod_t tod, int *display){
    //the two cases below checks for failure conditions
    if(tod.time_secs > 59 || tod.time_secs < 0 || tod.time_hours > 12 || tod.time_hours < 0 || tod.time_mins > 59 || tod.time_mins < 0) {
        return 1;
    }
    if(tod.ampm != 2 && tod.ampm != 1){
        return 1;
    }
    //array of bits
    int mask_arr[] = {0b1110111, 0b0100100, 0b1011101, 0b1101101, 0b0101110, 0b1101011, 0b1111011, 0b0100101, 0b1111111, 0b1101111};
    //calculate ones and ten digits
    int min_ones = tod.time_mins % 10;
    int min_tens = (tod.time_mins / 10);
    int hour_ones = tod.time_hours % 10;
    int hour_tens = (tod.time_hours / 10);
    int bits_display = 0;

    //shifting bits
    bits_display = bits_display | (mask_arr[min_ones] << 0);
    bits_display = bits_display | (mask_arr[min_tens] << 7);
    bits_display = bits_display | (mask_arr[hour_ones] << 14);

    //case for when shifting tens didgit of hour
    if(tod.time_hours > 9){
        bits_display = bits_display | (mask_arr[hour_tens] << 21);
    }
    
    //determines if am or pm and then shifts to 28 if am, 29 if pm
    if(tod.ampm == 1){
        bits_display = bits_display | (1 << 28);
    }
    else{
        bits_display = bits_display | (1 << 29);
    }
    *display = bits_display;
    return 0;
}

// Accepts a tod and alters the bits in the int pointed at by display
// to reflect how the LCD clock should appear. If any time_** fields
// of tod are negative or too large (e.g. bigger than 12 for hours,
// bigger than 59 for min/sec) or if the AM/PM is not 1 or 2, no
// change is made to display and 1 is returned to indicate an
// error. The display pattern is constructed via shifting bit patterns
// representing digits and using logical operations to combine them.
// May make use of an array of bit masks corresponding to the pattern
// for each digit of the clock to make the task easier.  Returns 0 to
// indicate success. This function DOES NOT modify any global
// variables
// 
// CONSTRAINT: Limit the complexity of code as much as possible. Do
// not use deeply nested conditional structures. Seek to make the code
// as short, and simple as possible. Code longer than 85 lines may be
// penalized for complexity.

int clock_update(){
    tod_t tod = {};
    int display = 0;
	if(set_tod_from_ports(&tod) == 1){ 
		return 1;
	}
	set_display_from_tod(tod, &display);
    CLOCK_DISPLAY_PORT = display;
	return 0;
}
// Examines the TIME_OF_DAY_PORT global variable to determine hour,
// minute, and am/pm.  Sets the global variable CLOCK_DISPLAY_PORT bits
// to show the proper time.  If TIME_OF_DAY_PORT appears to be in error
// (to large/small) makes no change to CLOCK_DISPLAY_PORT and returns 1
// to indicate an error. Otherwise returns 0 to indicate success.
//
// Makes use of the previous two functions: set_tod_from_ports() and
// set_display_from_tod().
// 
// CONSTRAINT: Does not allocate any heap memory as malloc() is NOT
// available on the target microcontroller.  Uses stack and global
// memory only.